# Weatherstation1
A weather station using the STM32F030, BMP180 and NRF905
This MCU reads pressure and temperature from the BMP180 every minute and transmits it @ 432MHz on the NRF905 transceiver.
See ioprog.com for more details.
