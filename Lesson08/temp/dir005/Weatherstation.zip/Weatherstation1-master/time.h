// time.h RTC function prototypes and declarations
void initRTC();
